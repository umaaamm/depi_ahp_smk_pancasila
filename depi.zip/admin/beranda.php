      <div class="row">
    

    <div class="col-md-12">
        
        
      <div class="box box-primary">
      <div class="box-header with border">
        <h3 class="box-title">Selamat Datang</h3>
      </div>
      
      <div class="box-body">
       <h2> Website Pendaftaran SMK Pancasila</h2>
      </div>
</div>  
      </div>
    </div>
    
     

            
        